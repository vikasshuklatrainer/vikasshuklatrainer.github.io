AWS Glue Workshop Module 08 - Classifiers & Schema Discovery

Creates:
- custom semicolon CSV classifier
- custom JSON classifier
- dedicated CSV crawler
- dedicated JSON crawler

Reuses:
- Module 1 S3 bucket
- glue_demo_db
- AWSGlueWorkshopRole

Can delete after prior labs:
- Module 2 RDS crawler
- Module 2 VPC/RDS/Glue Connection if JDBC labs complete
- Module 6/7 workflows
- Module 4 Visual ETL jobs
- Module 5 notebook
