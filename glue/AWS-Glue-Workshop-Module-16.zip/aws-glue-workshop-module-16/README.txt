AWS Glue Workshop Module 16
============================

Observability, Monitoring & Operations

Prerequisites:
- Module 1 bucket/database/role
- Module 9 partitioned Catalog table
- Modules 13-15 strongly recommended

Upload:
scripts/observability-job.py
to:
s3://<bucket>/scripts/module16/observability-job.py

Deploy:
cloudformation/aws-glue-module-16-observability.yaml

Creates:
- Glue observability test job
- CloudWatch failed-task alarm
- CloudWatch duration alarm
- SNS alert topic
- Optional email subscription
- EventBridge Glue failure rule
- EventBridge IAM role

No EC2/RDS/VPC/NAT Gateway is created.

Important:
If an email is supplied, SNS sends a confirmation message. The recipient must confirm the subscription before email alerts are delivered.

Cleanup:
Delete the Module 16 CloudFormation stack and module16/ S3 output.
Remove any manually created CloudWatch dashboards/alarms/rules.
If the SNS email subscription is manually managed, verify it is no longer needed.

Operational exercises:
- successful run
- forced failure
- alarm state transition
- EventBridge failure notification
- CloudWatch log triage
- SLA/SLO calculation
- production runbook exercise
