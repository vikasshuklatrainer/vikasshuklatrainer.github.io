import sys, time, logging
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from pyspark.sql import functions as F

args = getResolvedOptions(sys.argv, ["JOB_NAME","DATABASE","TABLE","OUTPUT_PATH"])

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("module16")

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session

job = Job(glueContext)
job.init(args["JOB_NAME"], args)

start = time.time()

source = glueContext.create_dynamic_frame.from_catalog(
    database=args["DATABASE"],
    table_name=args["TABLE"],
    transformation_ctx="observability_source"
)

df = source.toDF()

log.info("MODULE16_INPUT_COLUMNS=%s", df.columns)

if "quantity" in df.columns and "unit_price" in df.columns:
    result = df.withColumn(
        "line_value",
        F.col("quantity").cast("double") * F.col("unit_price").cast("double")
    )
else:
    result = df

result.write.mode("overwrite").format("parquet").option("compression","snappy").save(args["OUTPUT_PATH"])

log.info("MODULE16_INPUT_RECORDS=%s", df.count())
log.info("MODULE16_ELAPSED_SECONDS=%.2f", time.time() - start)

job.commit()
