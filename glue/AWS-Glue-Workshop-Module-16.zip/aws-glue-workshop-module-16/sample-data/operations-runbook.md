# Module 16 Operations Runbook

## Job failed
1. Identify JobRunId and state.
2. Open Glue job run details.
3. Check CloudWatch logs.
4. Identify error category.
5. Check input data/schema/permissions/network.
6. Decide retry vs remediation.
7. Re-run only after root cause is understood.
8. Record incident and outcome.

## Job is slow
1. Compare duration with baseline.
2. Check bytes read/written.
3. Check worker/memory/disk utilization.
4. Check skew and failed tasks.
5. Check partition pruning.
6. Check small files.
7. Tune one variable.
8. Re-measure.

## Alert fired
1. Determine whether it is job failure, duration, failed tasks, or data-quality signal.
2. Identify affected workflow/job.
3. Open run details and logs.
4. Check whether retry already occurred.
5. Escalate if SLA/SLO is at risk.

## Production principle
Do not automatically retry deterministic data-quality failures forever.
