AWS Glue Hands-on Workshop - Module 3
=========================================

Module 3: AWS Glue ETL

Builds on:
- Module 1: S3 + Glue Data Catalog + IAM
- Module 2: VPC + RDS PostgreSQL + Glue Connection

CloudFormation:
- cloudformation/aws-glue-module-03-etl-jobs.yaml

Scripts:
- scripts/s3-sales-etl.py
- scripts/rds-to-s3-etl.py

Important:
1. Deploy Modules 1 and 2 first.
2. Upload the two Python scripts to the Module 1 bucket under scripts/.
3. Deploy Module 3.
4. Run the S3 ETL and JDBC ETL jobs.
5. The Module 2 RDS crawler is optional after its discovery exercise; the JDBC Connection is still required.
