import sys
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from pyspark.sql.functions import col, round as spark_round

args = getResolvedOptions(sys.argv, ["JOB_NAME", "SOURCE_DATABASE", "OUTPUT_PATH"])

sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args["JOB_NAME"], args)

database = args["SOURCE_DATABASE"]
output_path = args["OUTPUT_PATH"]

customers = glueContext.create_dynamic_frame.from_catalog(
    database=database,
    table_name="customers",
    transformation_ctx="customers_source"
).toDF()

products = glueContext.create_dynamic_frame.from_catalog(
    database=database,
    table_name="products",
    transformation_ctx="products_source"
).toDF()

orders = glueContext.create_dynamic_frame.from_catalog(
    database=database,
    table_name="orders",
    transformation_ctx="orders_source"
).toDF()

result = (
    orders.alias("o")
    .join(customers.alias("c"), col("o.customer_id") == col("c.customer_id"), "inner")
    .join(products.alias("p"), col("o.product_id") == col("p.product_id"), "inner")
    .select(
        col("o.order_id"),
        col("o.order_date"),
        col("c.customer_id"),
        col("c.customer_name"),
        col("c.country"),
        col("p.product_id"),
        col("p.product_name"),
        col("p.category"),
        col("o.quantity"),
        col("o.order_amount"),
        col("o.order_status")
    )
    .withColumn("order_amount", spark_round(col("order_amount"), 2))
)

result.write.mode("append").format("parquet").save(output_path)

job.commit()
