import sys
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext

args = getResolvedOptions(
    sys.argv,
    ["JOB_NAME", "CONNECTION_NAME", "DB_TABLE", "OUTPUT_PATH"]
)

sc = SparkContext.getOrCreate()
glueContext = GlueContext(sc)
job = Job(glueContext)
job.init(args["JOB_NAME"], args)

source = glueContext.create_dynamic_frame.from_options(
    connection_type="postgresql",
    connection_options={
        "useConnectionProperties": "true",
        "connectionName": args["CONNECTION_NAME"],
        "dbtable": args["DB_TABLE"]
    },
    transformation_ctx="rds_source"
)

source.toDF().write.mode("overwrite").format("parquet").save(args["OUTPUT_PATH"])

job.commit()
