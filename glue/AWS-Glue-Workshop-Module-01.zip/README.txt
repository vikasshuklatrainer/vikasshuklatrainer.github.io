AWS Glue Hands-on Workshop - Module 1
=========================================

Files:
- AWS-Glue-Workshop-Module-01.html
- sample-data/customers.csv
- sample-data/products.csv
- sample-data/orders.csv
- sample-data/customers.json

Upload:
s3://<your-bucket>/raw/customers/customers.csv
s3://<your-bucket>/raw/products/products.csv
s3://<your-bucket>/raw/orders/orders.csv

The HTML contains the detailed IAM, S3, Glue Catalog, Database, Crawler,
Classifier, Table, Athena validation, troubleshooting and cleanup steps.


CloudFormation:
- cloudformation/aws-glue-module-01-foundation.yaml
- The complete YAML is also embedded inline in the HTML documentation.
