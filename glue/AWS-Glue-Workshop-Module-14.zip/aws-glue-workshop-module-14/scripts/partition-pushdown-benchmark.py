import sys, time
from awsglue.context import GlueContext
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from pyspark.sql import functions as F

args = getResolvedOptions(sys.argv, ["JOB_NAME","DATABASE","TABLE","OUTPUT_PATH"])
sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session

predicate = "(year=='2026' and month=='10' and day=='03')"
start = time.time()

source = glueContext.create_dynamic_frame.from_catalog(
    database=args["DATABASE"],
    table_name=args["TABLE"],
    push_down_predicate=predicate,
    transformation_ctx="pushdown_source"
)
df = source.toDF()

df.groupBy("product_id").agg(F.sum("quantity").alias("qty")).write.mode("overwrite").format("parquet").save(args["OUTPUT_PATH"])

print(f"MODULE14_PUSHDOWN_SECONDS={time.time()-start:.2f}")
print(f"MODULE14_PUSHDOWN_COUNT={df.count()}")
