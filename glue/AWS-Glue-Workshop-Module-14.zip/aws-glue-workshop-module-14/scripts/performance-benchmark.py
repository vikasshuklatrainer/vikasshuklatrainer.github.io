import sys, time
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from pyspark.sql import functions as F

args = getResolvedOptions(sys.argv, ["JOB_NAME","DATABASE","TABLE","OUTPUT_PATH"])

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args["JOB_NAME"], args)

start = time.time()

source = glueContext.create_dynamic_frame.from_catalog(
    database=args["DATABASE"],
    table_name=args["TABLE"],
    transformation_ctx="benchmark_source"
)

df = source.toDF()
result = (
    df.groupBy("product_id")
      .agg(
          F.count("*").alias("order_count"),
          F.sum("quantity").alias("total_quantity"),
          F.sum(F.col("quantity") * F.col("unit_price")).alias("revenue")
      )
)

result.write.mode("overwrite").format("parquet").option("compression","snappy").save(args["OUTPUT_PATH"])

elapsed = time.time() - start
print(f"MODULE14_BENCHMARK_SECONDS={elapsed:.2f}")
print(f"MODULE14_INPUT_COUNT={df.count()}")
job.commit()
