# Module 14 Performance Test Plan

Run the same workload with:
1. Fixed workers: G.1X x 2
2. Fixed workers: G.1X x 4
3. Auto Scaling: G.1X, maximum 4
4. Partition pushdown: day=03

Record:
- Job run duration
- DPU hours / DPUSeconds where available
- input records
- output size
- worker utilization
- number of executors
- errors/retries

Do not conclude that the fastest run is automatically the cheapest. Compare runtime and resource consumption.
