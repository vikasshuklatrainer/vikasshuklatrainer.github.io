AWS Glue Workshop Module 14
============================

Performance & FinOps Optimization

Prerequisites:
- Module 1 bucket/database/role
- Module 9 partitioned Catalog table
- Module 13 production ETL concepts are strongly recommended

Upload:
scripts/performance-benchmark.py
scripts/partition-pushdown-benchmark.py

to:
s3://<bucket>/scripts/module14/

Deploy:
cloudformation/aws-glue-module-14-performance-finops.yaml

Jobs:
- glue-module14-fixed-benchmark
- glue-module14-autoscaling-benchmark
- glue-module14-pushdown-benchmark

The stack creates no EC2, RDS, VPC or NAT Gateway.

Core exercises:
- baseline performance measurement
- G.1X vs G.2X
- worker count comparison
- Auto Scaling
- partition pushdown
- Parquet + Snappy
- small-file discussion
- skew and shuffle discussion
- timeout/retry controls
- DPUSeconds/DPU usage
- runtime vs cost analysis

Cleanup:
Delete the Module 14 CloudFormation stack and module14/ S3 objects.
Keep Module 1/9 resources if continuing.
