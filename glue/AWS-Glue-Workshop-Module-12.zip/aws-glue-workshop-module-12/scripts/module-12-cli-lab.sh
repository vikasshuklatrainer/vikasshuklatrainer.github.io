#!/usr/bin/env bash
set -euo pipefail

# Replace these values.
ACCOUNT_ID="<ACCOUNT_ID>"
DATABASE="glue_demo_db"
TABLE="m9_partitioned_sales"
ANALYST_ROLE_ARN="arn:aws:iam::${ACCOUNT_ID}:role/<ANALYST_ROLE_NAME>"

# Inspect the current Lake Formation state.
aws lakeformation get-data-lake-settings
aws lakeformation list-resources
aws lakeformation list-lf-tags

# Example: search tables by LF-Tag.
aws lakeformation search-tables-by-lf-tags \
  --expression "TagKey=data_classification,TagValues=public"

# Example: inspect the row/column filter.
aws lakeformation get-data-cells-filter \
  --table-catalog-id "${ACCOUNT_ID}" \
  --database-name "${DATABASE}" \
  --table-name "${TABLE}" \
  --name "module12-customer-id-exclusion"

# Hybrid access mode opt-in is intentionally a manual step in this lab:
# aws lakeformation create-lake-formation-opt-in \
#   --principal "DataLakePrincipalIdentifier=${ANALYST_ROLE_ARN}" \
#   --resource "{\"Table\":{\"CatalogId\":\"${ACCOUNT_ID}\",\"DatabaseName\":\"${DATABASE}\",\"Name\":\"${TABLE}\"}}"
