AWS Glue Workshop Module 12
=============================
Topic: AWS Lake Formation Security

Prerequisites:
- Module 1: workshop S3 bucket and glue_demo_db.
- Module 9: partitioned sales Catalog table.
- Module 11: Athena is recommended for testing access.
- Deploy as a Lake Formation data lake administrator.

CloudFormation:
cloudformation/aws-glue-module-12-lake-formation.yaml

The template:
- Registers the Module 9 S3 prefix in Lake Formation Hybrid Access Mode.
- Creates an LF-Tag data_classification={public,confidential}.
- Tags the Module 9 table public.
- Tags customer_id confidential.
- Creates an LF-Tag-based SELECT/DESCRIBE grant for the supplied analyst role.
- Creates a DataCellsFilter that excludes customer_id.
- Grants DATA_LOCATION_ACCESS to the analyst role.

Important:
Hybrid access mode requires the analyst principal to be opted in before Lake
Formation permissions become effective. The template intentionally does not
change account-wide DataLakeSettings or revoke IAMAllowedPrincipals because
those are potentially disruptive account-level operations.

After deployment:
1. Open Lake Formation -> Hybrid access mode.
2. Add the AnalystRole and Module 9 table as an opted-in principal/resource.
3. Test Athena with the analyst role.
4. Compare access before/after opt-in.
5. For a pure Lake Formation (non-hybrid) exercise, separately register the
   location in Lake Formation mode and remove IAMAllowedPrincipals permissions
   only in a dedicated lab environment.

Cleanup:
- Delete the Module 12 stack.
- Remove any manually created hybrid-access opt-in.
- Verify the S3 location registration and LF permissions are removed.
- Delete manual test role if it was created only for this lab.
- Keep Module 1 bucket/database and Module 9 table for later modules.
