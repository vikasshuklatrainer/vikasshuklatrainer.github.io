AWS Glue Workshop Module 11
============================
Topic: Athena analytics over AWS Glue Data Catalog.

Prerequisites:
- Module 1: existing S3 workshop bucket and glue_demo_db.
- Module 9: partitioned sales Catalog table.
- Module 10: optional data-quality validation.

CloudFormation:
cloudformation/aws-glue-module-11-athena.yaml

The template creates only an Athena WorkGroup. It reuses the Module 1 S3 bucket.
The WorkGroup writes Athena query results under module11/athena-results/ and
enforces a 100 MB default per-query scan cutoff.

SQL:
sql/module-11-athena-lab.sql

IMPORTANT:
- Replace REPLACE_WITH_BUCKET in the CTAS example.
- CTAS external_location must be an empty/new S3 location.
- Because the supplied WorkGroup enforces its result configuration, review the
  CTAS/workgroup interaction in the HTML before running the CTAS statement.

Cleanup:
- Delete the Module 11 CloudFormation stack.
- Delete module11/ Athena results and CTAS output.
- Drop Module 11 views/tables if they are no longer needed.
- Do not delete Module 1 bucket/database/role or Module 9 table if later modules need them.
