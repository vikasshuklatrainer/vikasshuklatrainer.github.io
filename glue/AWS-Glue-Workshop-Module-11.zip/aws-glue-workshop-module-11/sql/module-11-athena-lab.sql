-- Module 11 Athena query lab
-- Select AwsDataCatalog and glue_demo_db in Athena.

-- 1. Inspect the table
SELECT *
FROM "glue_demo_db"."m9_partitioned_sales"
LIMIT 20;

-- 2. Count rows
SELECT count(*) AS orders
FROM "glue_demo_db"."m9_partitioned_sales";

-- 3. Partition-aware query: only one day
SELECT
  year, month, day,
  count(*) AS orders,
  sum(quantity * unit_price) AS sales_amount
FROM "glue_demo_db"."m9_partitioned_sales"
WHERE year = '2026'
  AND month = '10'
  AND day = '03'
GROUP BY year, month, day;

-- 4. Aggregate by product
SELECT
  product_id,
  sum(quantity) AS units,
  sum(quantity * unit_price) AS revenue
FROM "glue_demo_db"."m9_partitioned_sales"
WHERE year = '2026' AND month = '10'
GROUP BY product_id
ORDER BY revenue DESC;

-- 5. View: views do not materialize a new data copy
CREATE OR REPLACE VIEW "glue_demo_db"."v_m11_daily_sales" AS
SELECT
  year, month, day,
  count(*) AS orders,
  sum(quantity * unit_price) AS revenue
FROM "glue_demo_db"."m9_partitioned_sales"
GROUP BY year, month, day;

-- 6. Query the view
SELECT * FROM "glue_demo_db"."v_m11_daily_sales"
ORDER BY year, month, day;

-- 7. CTAS example.
-- IMPORTANT: use a new/empty S3 location when workgroup enforcement allows
-- the CTAS destination. See the HTML lab instructions.
-- This example converts CSV query output into Parquet.
CREATE TABLE "glue_demo_db"."m11_sales_parquet"
WITH (
  format = 'PARQUET',
  write_compression = 'SNAPPY',
  external_location = 's3://REPLACE_WITH_BUCKET/module11/ctas/sales_parquet/'
)
AS
SELECT *
FROM "glue_demo_db"."m9_partitioned_sales"
WHERE year = '2026' AND month = '10';

-- 8. EXPLAIN query plan
EXPLAIN
SELECT sum(quantity * unit_price)
FROM "glue_demo_db"."m9_partitioned_sales"
WHERE year='2026' AND month='10' AND day='03';
