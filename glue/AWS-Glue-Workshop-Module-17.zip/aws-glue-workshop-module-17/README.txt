AWS Glue Workshop Module 17
============================

END-TO-END PRODUCTION CAPSTONE

This module integrates:
- Glue Catalog
- Job bookmarks/incremental source processing
- ETL transformation
- Parquet/Snappy
- Partitioned output
- Data Quality gate
- Glue Workflow
- Conditional triggers
- Curated Catalog crawler
- CloudWatch/Glue observability settings
- IAM execution role
- Production runbook

Prerequisites:
Modules 1, 9, 10, 12, 13, 14, 15 and 16 are strongly recommended.

Upload scripts to:
s3://<bucket>/scripts/module17/

Files:
- capstone-transform.py
- capstone-quality-gate.py
- capstone-publish.py

Deploy:
cloudformation/aws-glue-module-17-production-capstone.yaml

Workflow:
Start -> Transform -> Quality Gate -> Publish -> Crawler

Important:
The workflow is ON_DEMAND. It does not schedule recurring runs automatically.

The Data Quality gate is implemented in the ETL job using DQDL. If the gate fails,
the job raises an exception and the Publish trigger does not fire.

No EC2/RDS/VPC/NAT Gateway is created.

Cleanup:
- Stop the workflow/jobs.
- Delete Module 17 CloudFormation stack.
- Delete module17/ S3 objects.
- Keep Modules 1/9/12/13/15/16 if continuing or reviewing.
