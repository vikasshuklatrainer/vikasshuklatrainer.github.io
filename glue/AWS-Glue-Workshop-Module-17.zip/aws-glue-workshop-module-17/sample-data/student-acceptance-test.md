# Module 17 Capstone Acceptance Test

1. Deploy the CloudFormation stack.
2. Upload all three scripts.
3. Start the workflow.
4. Confirm Transform SUCCEEDED.
5. Confirm Data Quality SUCCEEDED.
6. Confirm Publish SUCCEEDED.
7. Confirm crawler SUCCEEDED.
8. Find the m17_ table in the Glue Catalog.
9. Query the curated data using Athena.
10. Add an intentionally bad record.
11. Run the workflow again.
12. Demonstrate that the DQ gate prevents publication when the rules fail.
13. Inspect logs and DQ results.
14. Explain which Module 13/14/15/16 patterns are visible in the capstone.
