# Module 17 Capstone Runbook

## Pipeline
ON_DEMAND
  -> Transform
  -> Data Quality Gate
  -> Publish
  -> Curated Crawler

## Success criteria
- Transform SUCCEEDED
- DQ gate SUCCEEDED
- Publish SUCCEEDED
- Curated crawler SUCCEEDED
- m17_* table visible in Glue Catalog
- Curated Parquet queryable from Athena

## Failure handling
Transform failed:
- inspect source schema/bookmark/logs

DQ failed:
- do not publish
- inspect DQ results
- correct source or rules
- rerun intentionally

Publish failed:
- inspect output path and IAM
- verify previous curated state
- rerun after root cause is fixed

Crawler failed:
- inspect role/S3/catalog permissions
- verify curated objects exist

## Production extension
Add EventBridge notifications, CloudWatch alarms, Lake Formation grants, KMS encryption,
quarantine, CI/CD deployment, approval gates and a replay strategy.
