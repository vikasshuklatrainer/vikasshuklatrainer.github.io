import sys, logging
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext

args = getResolvedOptions(sys.argv, ["JOB_NAME","INPUT_PATH","OUTPUT_PATH"])

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("module17-publish")

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args["JOB_NAME"], args)

source = glueContext.create_dynamic_frame.from_options(
    connection_type="s3",
    connection_options={"paths": [args["INPUT_PATH"]], "recurse": True},
    format="parquet",
    transformation_ctx="capstone_publish_source"
)

df = source.toDF()

# Publication boundary: only the data that passed the preceding DQ gate arrives here.
df.write.mode("overwrite").partitionBy("pipeline_date").format("parquet").option(
    "compression", "snappy"
).save(args["OUTPUT_PATH"])

log.info("CAPSTONE_PUBLISHED_RECORDS=%s", df.count())
job.commit()
