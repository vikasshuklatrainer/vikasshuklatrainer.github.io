import sys, logging
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.utils import getResolvedOptions
from awsglue.transforms import *
from awsgluedq.transforms import EvaluateDataQuality
from pyspark.context import SparkContext

args = getResolvedOptions(sys.argv, ["JOB_NAME","INPUT_PATH","DQ_RESULTS_PATH"])

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("module17-quality")

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args["JOB_NAME"], args)

source = glueContext.create_dynamic_frame.from_options(
    connection_type="s3",
    connection_options={"paths": [args["INPUT_PATH"]], "recurse": True},
    format="parquet",
    transformation_ctx="capstone_quality_source"
)

ruleset = '''
Rules = [
  IsComplete "order_id",
  IsComplete "customer_id",
  IsComplete "product_id",
  ColumnValues "quantity" > 0,
  ColumnValues "unit_price" > 0,
  RowCount > 0
]
'''

results = EvaluateDataQuality.apply(
    frame=source,
    ruleset=ruleset,
    publishing_options={
        "dataQualityEvaluationContext": "module17_capstone",
        "enableDataQualityCloudWatchMetrics": True,
        "resultsS3Prefix": args["DQ_RESULTS_PATH"]
    }
)

failed = results.filter(lambda r: str(r.get("DataQualityEvaluationResult", "")).upper() == "FAIL")
failed_count = failed.count()

log.info("CAPSTONE_DQ_FAILED_RESULTS=%s", failed_count)

if failed_count > 0:
    raise RuntimeError("CAPSTONE_DATA_QUALITY_GATE_FAILED")

job.commit()
