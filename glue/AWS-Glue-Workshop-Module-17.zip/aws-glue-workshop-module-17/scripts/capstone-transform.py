import sys, logging
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from pyspark.sql import functions as F

args = getResolvedOptions(sys.argv, ["JOB_NAME","DATABASE","TABLE","OUTPUT_PATH"])

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("module17-transform")

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args["JOB_NAME"], args)

source = glueContext.create_dynamic_frame.from_catalog(
    database=args["DATABASE"],
    table_name=args["TABLE"],
    transformation_ctx="capstone_source"
)

df = source.toDF()

# Normalize numeric fields when present.
if "quantity" in df.columns:
    df = df.withColumn("quantity", F.col("quantity").cast("double"))
if "unit_price" in df.columns:
    df = df.withColumn("unit_price", F.col("unit_price").cast("double"))
if "quantity" in df.columns and "unit_price" in df.columns:
    df = df.withColumn("sales_amount", F.col("quantity") * F.col("unit_price"))

# Add an operational processing timestamp.
df = df.withColumn("processed_at", F.current_timestamp())

# Partition by processing date for a deterministic classroom output layout.
df = df.withColumn("pipeline_date", F.to_date(F.col("processed_at")))

df.write.mode("overwrite").partitionBy("pipeline_date").format("parquet").option(
    "compression", "snappy"
).save(args["OUTPUT_PATH"])

log.info("CAPSTONE_TRANSFORM_RECORDS=%s", df.count())
job.commit()
