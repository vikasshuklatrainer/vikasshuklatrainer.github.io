AWS Glue Workshop Module 05 - Notebooks & Interactive Sessions

Primary files:
- AWS-Glue-Workshop-Module-05.html
- notebooks/Module-05-Glue-Notebook-Starter.ipynb

No CloudFormation stack is required for the core module. AWS Glue Studio notebooks use
Interactive Sessions and the existing Glue execution/runtime role can be reused.

Carry-forward:
KEEP Module 1 S3 bucket, Glue database, catalog tables and AWSGlueWorkshopRole.
KEEP Module 2 VPC/RDS/Glue Connection only if the optional PostgreSQL notebook lab is taught.
OPTIONALLY DELETE Module 2 RDS crawler after discovery.
OPTIONALLY DELETE Module 3 ETL jobs after script-vs-notebook comparison.
OPTIONALLY DELETE Module 4 Visual ETL jobs after visual-vs-notebook comparison.

Important:
Interactive Sessions do not support job bookmarks. Use production Glue Jobs for bookmark-based
incremental processing.
The notebook creator/client principal needs appropriate Glue notebook/session permissions and
iam:PassRole to the runtime role.
