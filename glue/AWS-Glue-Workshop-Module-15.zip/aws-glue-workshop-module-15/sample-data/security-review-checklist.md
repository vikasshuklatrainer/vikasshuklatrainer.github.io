# Module 15 Security Review

- [ ] Glue execution role uses only required S3 prefixes.
- [ ] Secrets are retrieved from Secrets Manager.
- [ ] Secret values are never written to logs.
- [ ] KMS key has rotation enabled where appropriate.
- [ ] S3 data is encrypted at rest.
- [ ] TLS/in-transit controls are enabled.
- [ ] Lake Formation permissions are tested with a dedicated role.
- [ ] IAMAllowedPrincipals behavior is understood before changing it.
- [ ] CloudTrail is available for audit.
- [ ] Production roles do not use AdministratorAccess.
- [ ] Cross-account sharing is documented and tested.
- [ ] Hybrid access mode changes are planned and reversible.
