import sys, json, logging
import boto3
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext
from pyspark.sql import functions as F

args = getResolvedOptions(sys.argv, [
    "JOB_NAME","DATABASE","TABLE","OUTPUT_PATH","SECRET_ARN","KMS_KEY_ARN"
])

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("module15")

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args["JOB_NAME"], args)

# Retrieve secret at runtime. Never log the secret value.
sm = boto3.client("secretsmanager")
secret = json.loads(sm.get_secret_value(SecretId=args["SECRET_ARN"])["SecretString"])
log.info("Secret retrieved for principal %s; secret value is intentionally not logged.", secret["username"])

source = glueContext.create_dynamic_frame.from_catalog(
    database=args["DATABASE"],
    table_name=args["TABLE"],
    transformation_ctx="security_source"
).toDF()

# Minimal demonstration transformation.
out = source.limit(100)

# SSE-KMS example. The S3 destination must be configured to use the KMS key.
hadoop_conf = spark.sparkContext._jsc.hadoopConfiguration()
hadoop_conf.set("fs.s3a.server-side-encryption-algorithm", "SSE-KMS")
hadoop_conf.set("fs.s3a.server-side-encryption-key", args["KMS_KEY_ARN"])

out.write.mode("overwrite").format("parquet").option("compression","snappy").save(args["OUTPUT_PATH"])

log.info("Security test completed; output written with KMS encryption configuration.")
job.commit()
