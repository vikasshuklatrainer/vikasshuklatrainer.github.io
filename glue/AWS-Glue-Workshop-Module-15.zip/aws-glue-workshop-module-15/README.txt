AWS Glue Workshop Module 15
============================

Security, Secrets, Encryption & Governance

Prerequisites:
- Module 1: S3 bucket, Glue database, AWSGlueWorkshopRole
- Module 9: partitioned sales Catalog table
- Module 12: Lake Formation concepts strongly recommended
- Module 13: Secrets Manager concepts strongly recommended

Upload:
scripts/security-test.py
to:
s3://<bucket>/scripts/module15/security-test.py

Deploy:
cloudformation/aws-glue-module-15-security-governance.yaml

Creates:
- Customer-managed KMS key with rotation enabled
- KMS alias
- Secrets Manager secret encrypted with the KMS key
- Inline least-privilege policy on existing Glue role
- Security test Glue job

Does not create:
- EC2
- RDS
- VPC
- NAT Gateway
- Internet Gateway

Important:
This module deliberately does not change account-wide Lake Formation DataLakeSettings,
revoke IAMAllowedPrincipals, or register production S3 locations automatically.
Those are governance changes and should be demonstrated manually in a controlled lab.

Cleanup:
- Stop the Module 15 job.
- Delete the Module 15 CloudFormation stack.
- Delete module15/ S3 objects.
- Verify KMS key deletion scheduling if the stack is deleted.
- Verify the demo secret is removed.
- Keep Module 12 Lake Formation resources if continuing.
