AWS Glue Hands-on Workshop - Module 2
=========================================

Module 2: Glue Connections & Connectors

This module builds on Module 1 and demonstrates:
- Amazon RDS PostgreSQL as a relational source
- VPC/subnet/security group design
- Secrets Manager
- IAM role extension
- Glue Connection
- JDBC connectivity
- Glue crawler against PostgreSQL
- Connection vs Connector concepts
- Preparation for ETL

Important:
- Keep the database private where possible.
- Do not expose PostgreSQL 5432 to 0.0.0.0/0 in production.
- Do not put database passwords in code.
- RDS and NAT Gateway can incur charges; clean up after the lab.

CloudFormation:
- cloudformation/aws-glue-module-02-add-rds-connectivity.yaml
- The complete YAML is embedded inline in the HTML documentation.

Stack dependency:
1. Deploy Module 1.
2. Capture Module 1 Outputs.
3. Deploy Module 2 using those outputs as parameters.
4. Create the PostgreSQL schema/data.
5. Run the RDS crawler.
