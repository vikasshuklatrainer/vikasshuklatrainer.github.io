import sys
from awsglue.context import GlueContext
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext

args = getResolvedOptions(sys.argv, ["JOB_NAME", "DATABASE", "TABLE"])

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session

# Demonstrates partition pruning. The table must have year/month/day
# partition keys discovered by the Module 9 crawler.
push_down = "(year=='2026' and month=='10' and day=='03')"

df = glueContext.create_dynamic_frame.from_catalog(
    database=args["DATABASE"],
    table_name=args["TABLE"],
    push_down_predicate=push_down
).toDF()

df.createOrReplaceTempView("sales")
result = spark.sql("""
    SELECT
        year, month, day,
        COUNT(*) AS orders,
        SUM(quantity * unit_price) AS sales_amount
    FROM sales
    GROUP BY year, month, day
    ORDER BY year, month, day
""")

result.show(truncate=False)
