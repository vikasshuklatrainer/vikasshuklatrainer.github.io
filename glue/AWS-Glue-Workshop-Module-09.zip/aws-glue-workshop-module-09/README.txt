AWS Glue Workshop - Module 09
================================

Topic:
Partitions, Incremental Crawling & Data Catalog Optimization

Prerequisites:
- Module 1: S3 workshop bucket, glue_demo_db, AWSGlueWorkshopRole
- Modules 3/6/7 are useful for context but are not required to run this module.
- Module 8 can remain deployed; Module 9 uses a separate S3 prefix.

CloudFormation:
cloudformation/aws-glue-module-09-partitions.yaml

Sample data:
sample-data/partitioned-sales/year=2026/month=10/day=01/
sample-data/partitioned-sales/year=2026/month=10/day=02/
sample-data/partitioned-sales/year=2026/month=10/day=03/

Incremental exercise:
sample-data/new-partition/year=2026/month=10/day=04/

Important:
Upload the three initial partition folders under:
s3://<Module1Bucket>/module9/partitioned-sales/

For the incremental exercise, upload day=04 under the same root:
s3://<Module1Bucket>/module9/partitioned-sales/year=2026/month=10/day=04/

The CloudFormation crawler is configured with CRAWL_NEW_FOLDERS_ONLY and automatic
partition index creation.

Cleanup:
Delete the Module 9 CloudFormation stack and remove module9/ objects from the bucket.
Do not delete the Module 1 bucket, glue_demo_db or AWSGlueWorkshopRole unless the entire workshop is finished.
