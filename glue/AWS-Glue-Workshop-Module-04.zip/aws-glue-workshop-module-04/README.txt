AWS Glue Workshop Module 04 - Visual ETL

Files:
- AWS-Glue-Workshop-Module-04.html
- automation/visual-etl-automation-notes.json

This module intentionally does not include a primary CloudFormation template.
AWS::Glue::Job supports JobMode=VISUAL, but CloudFormation does not currently expose
the Glue Visual Job API's CodeGenConfigurationNodes property that registers the actual
visual DAG. Therefore the workshop creates the visual DAG in Glue Studio.

Carry-forward:
KEEP Module 1 S3 bucket, Glue database and execution role.
KEEP Module 2 network/RDS/Glue connection only if the optional PostgreSQL Visual ETL lab is taught.
OPTIONALLY DELETE Module 3 ETL jobs after the script-vs-visual comparison.
OPTIONALLY DELETE the Module 2 RDS crawler after discovery.
