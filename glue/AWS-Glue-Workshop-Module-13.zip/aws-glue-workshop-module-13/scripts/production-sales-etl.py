import sys, json, boto3, logging
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.utils import getResolvedOptions
from awsglue.dynamicframe import DynamicFrame
from pyspark.context import SparkContext
from awsglue.transforms import Filter, ApplyMapping

args = getResolvedOptions(sys.argv, [
    "JOB_NAME","DATABASE","TABLE","OUTPUT_PATH","QUARANTINE_PATH","SECRET_ARN"
])

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger("module13")

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args["JOB_NAME"], args)

# Never print the secret value. This demonstrates secure retrieval.
secrets = boto3.client("secretsmanager")
secret_meta = secrets.get_secret_value(SecretId=args["SECRET_ARN"])
secret = json.loads(secret_meta["SecretString"])
logger.info("Retrieved secret for user %s without logging the password.", secret["username"])

source = glueContext.create_dynamic_frame.from_catalog(
    database=args["DATABASE"],
    table_name=args["TABLE"],
    transformation_ctx="sales_source"
)

valid = Filter.apply(
    frame=source,
    f=lambda r: r.get("quantity") is not None and float(r.get("quantity")) > 0
               and r.get("unit_price") is not None and float(r.get("unit_price")) > 0,
    transformation_ctx="valid_records"
)

invalid = Filter.apply(
    frame=source,
    f=lambda r: not (
        r.get("quantity") is not None and float(r.get("quantity")) > 0
        and r.get("unit_price") is not None and float(r.get("unit_price")) > 0
    ),
    transformation_ctx="invalid_records"
)

valid_df = valid.toDF()
invalid_df = invalid.toDF()

if valid_df.take(1):
    valid_df.write.mode("append").format("parquet").save(args["OUTPUT_PATH"])

if invalid_df.take(1):
    invalid_df.write.mode("append").format("json").save(args["QUARANTINE_PATH"])

logger.info("Production ETL completed. Valid records were published; invalid records were quarantined.")
job.commit()
