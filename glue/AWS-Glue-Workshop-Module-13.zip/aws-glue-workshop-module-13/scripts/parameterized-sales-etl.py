import sys
from awsglue.context import GlueContext
from awsglue.job import Job
from awsglue.utils import getResolvedOptions
from pyspark.context import SparkContext

args = getResolvedOptions(sys.argv, ["JOB_NAME","DATABASE","TABLE","OUTPUT_PATH"])

sc = SparkContext()
glueContext = GlueContext(sc)
spark = glueContext.spark_session
job = Job(glueContext)
job.init(args["JOB_NAME"], args)

source = glueContext.create_dynamic_frame.from_catalog(
    database=args["DATABASE"],
    table_name=args["TABLE"],
    transformation_ctx="parameterized_source"
)

df = source.toDF()
df.write.mode("append").format("parquet").save(args["OUTPUT_PATH"])

job.commit()
