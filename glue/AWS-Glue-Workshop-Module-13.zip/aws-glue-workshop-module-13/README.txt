AWS Glue Workshop Module 13
============================
Production Glue ETL Patterns

Prerequisites:
- Module 1: workshop S3 bucket, glue_demo_db, AWSGlueWorkshopRole.
- Module 9: partitioned Catalog table.
- Module 10/11/12 are useful context but not required for the core jobs.

CloudFormation:
cloudformation/aws-glue-module-13-production-etl.yaml

Before running the jobs:
1. Upload scripts/production-sales-etl.py and scripts/parameterized-sales-etl.py
   to s3://<bucket>/scripts/module13/
2. Deploy the stack.
3. Confirm Module9TableName is the exact Catalog table name.
4. Run the parameterized job and production job.
5. Inspect CloudWatch logs, metrics and S3 output/quarantine.

The stack creates:
- One Secrets Manager demo secret.
- Two Glue jobs.
- One inline IAM policy on the existing Glue role.

It does not create VPC, RDS, EC2 or NAT Gateway.

Production concepts:
- Job parameters
- Job bookmarks
- MaxConcurrentRuns=1
- MaxRetries
- CloudWatch logging/metrics
- Secrets Manager
- Valid/invalid record routing
- Append-only curated output
- Quarantine path
- Explicit job.init/job.commit
- Never pass plaintext secrets as job arguments.

Cleanup:
- Delete Module 13 stack.
- Delete module13/ S3 objects.
- The stack removes its inline policy and demo secret.
- Keep Module 1/9/10/11 resources if later modules require them.
