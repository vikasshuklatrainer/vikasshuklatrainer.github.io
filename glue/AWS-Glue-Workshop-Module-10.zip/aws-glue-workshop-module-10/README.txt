AWS Glue Workshop Module 10
Data Quality, DQDL, rulesets, recommendations and ETL quality gates.

Prerequisites: Modules 1 and 9.
CloudFormation: cloudformation/aws-glue-module-10-data-quality.yaml
Samples: sample-data/good-sales.csv and sample-data/bad-sales.csv
Script: scripts/evaluate-sales-quality.py

If Module 9 created a different table name, pass that exact name as Module9TableName.
The template reuses the Module 1 bucket, database and IAM role; it creates no VPC/RDS/NAT/EC2.
