import sys
from awsglue.context import GlueContext
from awsglue.utils import getResolvedOptions
from awsgluedq.transforms import EvaluateDataQuality
from pyspark.context import SparkContext

args = getResolvedOptions(sys.argv, ["JOB_NAME", "DATABASE", "TABLE", "RESULTS_PATH"])
sc = SparkContext()
glueContext = GlueContext(sc)

source = glueContext.create_dynamic_frame.from_catalog(
    database=args["DATABASE"], table_name=args["TABLE"]
)

ruleset = '''
Rules = [
    IsComplete "order_id",
    IsUnique "order_id",
    IsComplete "customer_id",
    IsComplete "product_id",
    ColumnValues "quantity" > 0,
    ColumnValues "unit_price" > 0,
    RowCount > 0
]
'''

results = EvaluateDataQuality.apply(
    frame=source,
    ruleset=ruleset,
    publishing_options={
        "dataQualityEvaluationContext": "module10-sales-quality",
        "enableDataQualityCloudWatchMetrics": True,
        "resultsS3Prefix": args["RESULTS_PATH"]
    }
)
results.show(truncate=False)
